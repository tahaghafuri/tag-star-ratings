<?php

/**
 * Plugin Name:     TAG Star Rating
 * Plugin Slug:     tag-star-ratings
 * Plugin Nick:     tagsr
 * Plugin URI:      https://tagtech.ir/p/tag-star-rating/
 * Description:     با رتبه‌بندی پست‌ها، به بازدیدکنندگان وبلاگ اجازه دهید تا وب‌سایت شما را درگیر کنند و با آن تعامل مؤثرتری داشته باشند.
 * Author:          تگ تچ
 * Author URI:      https://tagtech.ir/
 * Text Domain:     tag-star-ratings
 * Version:         1.0.0
 */

if (! defined('ABSPATH')) {
    http_response_code(404);
    exit();
}

define('TAG_STAR_RATINGS', __FILE__);



require_once __DIR__.'/src/res.php';
