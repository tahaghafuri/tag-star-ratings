<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function migrators(array $data): array
{
    $migrators = [];

    foreach ($data as $filename => $options) {
        $parts = explode('/', $filename, 2);
        $semver = substr($parts[0], 1);
        $tag = $parts[1];

        [$handler, $payload] = $options();

        $migrators[] = (object) compact('handler', 'payload', 'semver', 'tag');
    }

    usort($migrators, function ($a, $b) {
        if ($a->semver === $b->semver) {
            return $a->tag <=> $b->tag;
        }

        return version_compare($a->semver, $b->semver);
    });

    return $migrators;
}
