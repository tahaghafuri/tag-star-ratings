<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\functions;

use InvalidArgumentException;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function view(string $__base, string $__path, array $__payload = []): string
{
    $resolve = function (string $base, string $path): string {
        if (is_file($path)) {
            return $path;
        }

        $path = ltrim($path, '\/');
        $directory = tagsr('slug').'/'.basename(dirname($base));
        $parentTheme = get_template_directory().'/'.$directory.'/'.$path;
        $childTheme = get_stylesheet_directory().'/'.$directory.'/'.$path;

        if (is_file($childTheme)) {
            return $childTheme;
        }

        if (is_file($parentTheme)) {
            return $parentTheme;
        }

        $template = $base.'/'.$path;

        if (is_file($template)) {
            return $template;
        }

        throw new InvalidArgumentException("قالب '{$path}' را نمی توان در '{$template}' یافت");
    };

    $__view = function (string $path, array $payload = []) use ($__payload, $__base) {
        return view($__base, $path, array_merge($__payload, $payload));
    };
    $__tagsr = 'tagsr';
    $__base = rtrim($__base, '\/');
    $__dusk = tagsr('functions.dusk_attr');
    $__template = $resolve($__base, $__path);

    unset($resolve);

    extract($__payload);

    ob_start();

    require $__template;

    return ob_get_clean();
}
