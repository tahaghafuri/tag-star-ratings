<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function type_cast($value, string $type)
{
    switch ($type) {
        case 'array': return (array) $value;
        case 'boolean': return (bool) $value;
        case 'double': return (float) $value;
        case 'float': return (float) $value;
        case 'integer': return (int) $value;
        case 'string': return (string) $value;
    }

    return $value;
}
