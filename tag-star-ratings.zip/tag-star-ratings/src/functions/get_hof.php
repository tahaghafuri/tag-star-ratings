<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function get_hof(?array $payload, callable $delegate, string $prefix = null, array $types = []): callable
{
    return function (string $key, $default = null) use ($payload, $delegate, $prefix, $types) {
        $key = strip_prefix($key, $prefix);

        $value = is_array($payload)
            ? ($payload[$prefix.$key] ?? null)
            : $delegate($key, $default);

        return [$prefix.$key, type_cast($value, $types[$key] ?? '')];
    };
}
