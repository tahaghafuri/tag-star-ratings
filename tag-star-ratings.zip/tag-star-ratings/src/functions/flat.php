<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

/** Flatten items into dot notation. */
function flat(array $items, int $depth = -1): array
{
    $flat = [];

    foreach ($items as $key => $value) {
        if (! is_array($value)
            || $depth == 0
        ) {
            $flat[$key] = $value;

            continue;
        }

        foreach (flat($value, $depth - 1) as $_key => $_value) {
            $flat[$key.'.'.$_key] = $_value;
        }
    }

    return $flat;
}
