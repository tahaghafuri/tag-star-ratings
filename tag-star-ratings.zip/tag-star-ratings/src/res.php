<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

require_once __DIR__.'/index.php';
require_once __DIR__.'/core/index.php';

// function that runs when shortcode is called
function tag_star_add_shortcode() { 

// Things that you want to do. 
$message = tag_star_ratings(); 

return $message;
} 
// register shortcode
add_shortcode('tagstarcode', 'tag_star_add_shortcode');
