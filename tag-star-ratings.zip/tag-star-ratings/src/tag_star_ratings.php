<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

use function Tagtech\StarRating\functions\to_shortcode;

/** @param int|string|array|object|WP_POST|null $idOrPostOrPayload */
function tag_star_ratings($idOrPostOrPayload = null): string
{
    $payload = [];

    if (is_array($idOrPostOrPayload)) {
        $payload = $idOrPostOrPayload;
    }

    if (is_object($idOrPostOrPayload)) {
        $payload['id'] = $idOrPostOrPayload->ID;
    }

    if ($idOrPostOrPayload) {
        $payload['id'] = $idOrPostOrPayload;
    }

    $payload['reference'] = 'template';

    return do_shortcode(to_shortcode(tagsr('slug'), $payload));
}
