<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

use function Tagtech\StarRating\functions\container;

/** @param string|array|null $keyOrItems */
function tagsr($keyOrItems = null, $default = null)
{
    static $config = [];

    return container($config, $keyOrItems, $default);
}
