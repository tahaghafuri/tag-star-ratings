<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\actions\admin;

use function Tagtech\StarRating\core\functions\action;
use function Tagtech\StarRating\core\functions\filter;
use function Tagtech\StarRating\core\functions\view;
use InvalidArgumentException;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function index(): void
{
    $tabs = filter('admin/tabs', []);
    reset($tabs);
    $active = filter('admin/active_tab', key($tabs) ?: 'general');

    foreach ($tabs as $slug => &$tab) {
        if (! is_array($tab)) {
            $tab = ['name' => $tab];
        }

        $tab = [
            'is_active' => $slug == $active,
        ] + $tab + [
            'is_active' => false,
            'is_addon' => false,
            'is_disabled' => false,
        ];
    }

    $errors = [];
    $payload = [];
    $processed = false;
    $nonce = __FUNCTION__;
    $filename = preg_replace(['/ +/', '/[^a-z0-9_]+/'], ['_', ''], strtolower($active));

    if (isset($_POST['submit'])) {
        $processed = true;
        $payload = $_POST;
        unset($payload['_wpnonce'], $payload['_wp_http_referer'], $payload['submit']);

        try {
            if (wp_verify_nonce($_POST['_wpnonce'] ?? null, $nonce) === false) {
                throw new InvalidArgumentException(__('شما فقط می توانید گزینه ها را از طریق ادمین ذخیره کنید.', 'tag-star-ratings'));
            }

            if ($filename) {
                action('admin/save/'.$filename, $payload, $active);
            }

            action('admin/save', $payload, $active);
        } catch (InvalidArgumentException $e) {
            if (is_string($name = $e->getCode())) {
                $errors[$name] = array_merge($errors[$name] ?? [], [$e->getMessage()]);
            } else {
                $errors[0] = array_merge($errors[0] ?? [], [$e->getMessage()]);
            }
        }
    }

    ob_start();
    action('admin/content', $errors ? $payload : null, $active);
    $content = ob_get_clean();

    if ($filename) {
        ob_start();
        action('admin/tabs/'.$filename, $errors ? $payload : null, $active);
        $content .= ob_get_clean();
    }

    $globalErrors = [];

    if ($errors) {
        $processed = false;
        $globalErrors[] = __('هنگام ذخیره گزینه ها برخی از خطاها وجود داشت.', 'tag-star-ratings');
    }

    $globalErrors = array_merge($globalErrors, $errors[0] ?? []);

    echo view('admin/index.php', [
        'active' => $active,
        'author' => tagsr('author'),
        'authorUrl' => tagsr('author_url'),
        'content' => $content,
        'errors' => $errors,
        'globalErrors' => $globalErrors,
        'label' => tagsr('name'),
        'nonce' => $nonce,
        'processed' => $processed,
        'slug' => tagsr('slug'),
        'tabs' => $tabs,
        'version' => tagsr('version'),
    ]);
}
