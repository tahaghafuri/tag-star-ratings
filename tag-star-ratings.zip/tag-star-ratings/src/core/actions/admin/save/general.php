<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\actions\admin\save;

use function Tagtech\StarRating\core\functions\option;
use function Tagtech\StarRating\core\functions\strip_prefix;
use function Tagtech\StarRating\functions\sanitize;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function general(array $payload, string $tab): void
{
    $payload = shortcode_atts(array_fill_keys([
        'enable',
        'exclude_categories',
        'locations',
        'strategies',
    ], null), strip_prefix($payload));

    option(sanitize($payload));
}
