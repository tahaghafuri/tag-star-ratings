<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\actions;

use function Tagtech\StarRating\core\functions\view;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function markup(array $payload): void
{
    echo view('markup/index.php', $payload);
}
