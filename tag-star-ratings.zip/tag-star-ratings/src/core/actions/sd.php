<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\actions;

use function Tagtech\StarRating\core\functions\ld_json;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function sd(array $payload): void
{
    echo ld_json($payload);
}
