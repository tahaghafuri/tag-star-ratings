<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\actions\metabox;

use function Tagtech\StarRating\core\functions\action;
use function Tagtech\StarRating\core\functions\view;
use WP_Post;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function index(?string $type, WP_Post $post = null): void
{
    ob_start();
    action('metabox/content', $type, $post);
    $content = ob_get_clean();

    echo view('metabox/index.php', compact('content'));
}
