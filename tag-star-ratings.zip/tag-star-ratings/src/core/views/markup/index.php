<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }
?>

<div class="tag-star-ratings
    <?php echo $valign ? (' tagsr-valign-'.esc_attr($valign)) : ''; ?>
    <?php echo $align ? (' tagsr-align-'.esc_attr($align)) : ''; ?>
    <?php echo $readonly ? ' tagsr-disabled' : ''; ?>"
    data-payload="<?php echo esc_attr(json_encode(array_map('esc_attr', $__payload))); ?>">
    <?php echo $__view('markup/stars.php'); ?>
    <?php echo $__view('markup/legend.php'); ?>
</div>
