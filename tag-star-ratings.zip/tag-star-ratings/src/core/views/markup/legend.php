<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }
?>

<div class="tagsr-legend">
    <?php if ($count) { ?>
        <?php echo esc_html($legend); ?>
    <?php } else { ?>
        <span class="tagsr-muted"><?php echo esc_html($greet); ?></span>
    <?php } ?>
</div>
