<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }
?>

<div class="tagsr-stars">
    <?php echo $__view('markup/inactive-stars.php'); ?>
    <?php echo $__view('markup/active-stars.php'); ?>
</div>
