<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }
?>

<div class="tagsr-icon" style="width: <?php echo esc_attr($size); ?>px; height: <?php echo esc_attr($size); ?>px;"></div>
