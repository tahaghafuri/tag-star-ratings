<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }

    $grs = $get('grs');
    $sd = $get('sd');
?>

<table class="form-table" role="presentation">
    <tbody>

        <!-- Status -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($grs[0]); ?>"><?php echo esc_html_x('وضعیت', 'Label', 'tag-star-ratings'); ?></label>
            </th>
            <td>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr($grs[0]); ?>" id="<?php echo esc_attr($grs[0]); ?>" value="1"<?php echo $grs[1] ? ' checked="checked"' : ''; ?>>
                    <?php echo esc_html_x('فعال', 'Label', 'tag-star-ratings'); ?>
                </label>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('فعال/غیرفعال کردن ریچ اسنیپت ها', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Structured Data -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($sd[0]); ?>"><?php echo esc_html_x('محتوا', 'Label', 'tag-star-ratings'); ?></label>
            </th>
            <td>
                <p>
                    <textarea type="text" name="<?php echo esc_attr($sd[0]); ?>" id="<?php echo esc_attr($sd[0]); ?>" rows="12" placeholder="ld+json" class="regular-text" style="font-family: monospace;"
                        ><?php echo esc_textarea($sd[1]); ?></textarea>
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('ساختار ld+json را ارائه دهید.', 'tag-star-ratings'); ?>
                    <br><br>
                    <?php echo esc_html__('متغیرهای زیر در دسترس هستند:', 'tag-star-ratings'); ?>
                    <br>
                    <?php echo sprintf(esc_html_x('%s عنوان پست', 'Label', 'tag-star-ratings'), '<code>{title}</code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html_x('%s میانگین امتیازات', 'Label', 'tag-star-ratings'), '<code>{score}</code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html_x('%s تعداد آرای داده شده', 'Label', 'tag-star-ratings'), '<code>{count}</code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html_x('%s تعداد کل ستاره ها', 'Label', 'tag-star-ratings'), '<code>{best}&nbsp;</code>'); ?>
                </p>
            </td>
        </tr>

    </tbody>
</table>
