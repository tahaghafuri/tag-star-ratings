<?php

    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }

    $enable = $get('enable');
    $excludeCategories = $get('exclude_categories');
    $locations = $get('locations');
    $strategies = $get('strategies');

    $postTypes = [
        'post' => 'مطالب',
        'page' => 'صفحات',
    ] + array_reduce(get_post_types([
        'publicly_queryable' => true,
        '_builtin' => false,
    ], 'objects'), function ($postTypes, $postType) {
        $postTypes[$postType->name] = $postType->labels->name;

        return $postTypes;
    }, []);

    $postCategories = array_reduce(get_terms([
        'taxonomy' => 'category',
        'hide_empty' => false,
        'parent' => 0,
    ]), function ($categories, $category) {
        $categories[$category->term_id] = $category->name;

        return $categories;
    }, []);

    $availableLocations = [
        'home' => _x('صفحه اصلی', 'Label', 'tag-star-ratings'),
        'archives' => _x('آرشیو ها', 'Label', 'tag-star-ratings'),
    ] + $postTypes;

    $availableStrategies = [
        'archives' => _x('اجازه رای دادن در آرشیو', 'Label', 'tag-star-ratings'),
        'guests' => _x('اجازه رای دادن به مهمان ها', 'Label', 'tag-star-ratings'),
        'unique' => _x('آرای منحصر به فرد (بر اساس آدرس IP)', 'Label', 'tag-star-ratings'),
    ];
?>

<table class="form-table" role="presentation">
    <tbody>

        <!-- Status -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($enable[0]); ?>"><?php echo esc_html_x('وضعیت', 'Label', 'tag-star-ratings'); ?></label>
            </th>
            <td>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr($enable[0]); ?>" id="<?php echo esc_attr($enable[0]); ?>" value="1"<?php echo $enable[1] ? ' checked="checked"' : ''; ?>>
                    <?php echo esc_html_x('فعال', 'Label', 'tag-star-ratings'); ?>
                </label>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('رده‌بندی ستاره‌ها را در سطح جهانی فعال/غیرفعال کنید.', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Strategies -->
        <tr>
            <th scope="row" valign="top">
                <?php echo esc_html_x('استراتژی ها', 'Label', 'tag-star-ratings'); ?>
            </th>
            <td>
                <?php foreach ($availableStrategies as $value => $label) { ?>
                    <p>
                        <label>
                            <input type="checkbox" name="<?php echo esc_attr($strategies[0]); ?>[]" value="<?php echo esc_attr($value); ?>"<?php echo (in_array($value, $strategies[1])) ? ' checked="checked"' : ''; ?>>
                            <?php echo esc_html($label); ?>
                        </label>
                    </p>
                <?php } ?>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('استراتژی های رای گیری را انتخاب کنید.', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Locations -->
        <tr>
            <th scope="row" valign="top">
                <?php echo esc_html_x('مکان ها', 'Label', 'tag-star-ratings'); ?>
            </th>
            <td>
                <?php foreach ($availableLocations as $type => $label) { ?>
                    <p>
                        <label>
                            <input type="checkbox" name="<?php echo esc_attr($locations[0]); ?>[]" value="<?php echo esc_attr($type); ?>"<?php echo (in_array($type, $locations[1])) ? ' checked="checked"' : ''; ?>>
                            <?php echo esc_html($label); ?>
                        </label>
                    </p>
                <?php } ?>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo sprintf(esc_html__('رتبه‌بندی‌های ستاره به‌طور خودکار برای مکان‌های انتخابی تعبیه می‌شوند. همچنان می‌توانید به‌صورت دستی رتبه‌بندی ستاره‌ها را برای مکان‌های انتخاب‌نشده/دیگر مجاز کنید. به عنوان مثال. استفاده كردن %s در فایل(های) تم/الگوی شما.', 'tag-star-ratings'), '<code>echo TAG_star_ratings();</code>'); ?>
                </p>
            </td>
        </tr>

        <!-- Exclude Categories -->
        <tr>
            <th scope="row" valign="top">
                <?php echo esc_html_x('مستثنی سازی دسته ها', 'Label', 'tag-star-ratings'); ?>
            </th>
            <td>
                <?php foreach ($postCategories as $value => $label) { ?>
                    <p>
                        <label>
                            <input type="checkbox" name="<?php echo esc_attr($excludeCategories[0]); ?>[]" value="<?php echo esc_attr($value); ?>"<?php echo (in_array($value, $excludeCategories[1])) ? ' checked="checked"' : ''; ?>>
                            <?php echo esc_html($label); ?>
                        </label>
                    </p>
                <?php } ?>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo sprintf(esc_html__('پست‌های متعلق به دسته‌های انتخابی رتبه‌بندی ستاره‌ها را به‌طور خودکار تعبیه نمی‌کنند. همچنان می‌توانید رتبه‌بندی‌های ستاره را به صورت دستی نشان دهید. به عنوان مثال. استفاده كردن %s در فایل(های) تم/الگوی شما.', 'tag-star-ratings'), '<code>echo TAG_star_ratings();</code>'); ?>
                </p>
            </td>
        </tr>
    </tbody>
</table>
