<?php
    if (! defined('TAG_STAR_RATINGS')) {
        http_response_code(404);
        exit();
    }

    $gap = $get('gap');
    $greet = $get('greet');
    $legend = $get('legend');
    $position = $get('position');
    $size = $get('size');
    $stars = $get('stars');

    $positions = [
        'top-left' => _x('بالا چپ', 'Label', 'tag-star-ratings'),
        'top-center' => _x('بالا وسط', 'Label', 'tag-star-ratings'),
        'top-right' => _x('بالا راست', 'Label', 'tag-star-ratings'),
        'bottom-left' => _x('پایین چپ', 'Label', 'tag-star-ratings'),
        'bottom-center' => _x('پایین وسط', 'Label', 'tag-star-ratings'),
        'bottom-right' => _x('پایین راسط', 'Label', 'tag-star-ratings'),
    ];
?>

<table class="form-table" role="presentation">
    <tbody>
        <!-- Greet -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($greet[0]); ?>">
                    <?php echo esc_html_x('احوال پرسی', 'Label', 'tag-star-ratings'); ?>
                </label>
            </th>
            <td>
                <p>
                    <input type="text" name="<?php echo esc_attr($greet[0]); ?>" id="<?php echo esc_attr($greet[0]); ?>" value="<?php echo esc_attr($greet[1]); ?>" placeholder="به این {type} امتیاز دهید" class="regular-text" style="font-family: monospace;">
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('متنی که در صورت عدم رای گیری نمایش داده می شود.', 'tag-star-ratings'); ?>
                    <br><br>
                    <?php echo esc_html__('متغیرهای زیر در دسترس هستند:', 'tag-star-ratings'); ?>
                    <br>
                    <?php echo sprintf(esc_html__('%s نوع پست', 'tag-star-ratings'), '<code>{type}</code>'); ?>
                </p>
            </td>
        </tr>

        <!-- Legend -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($legend[0]); ?>">
                    <?php echo esc_html_x('افسانه', 'Label', 'tag-star-ratings'); ?>
                </label>
            </th>
            <td>
                <p>
                    <input type="text" name="<?php echo esc_attr($legend[0]); ?>" id="<?php echo esc_attr($legend[0]); ?>" value="<?php echo esc_attr($legend[1]); ?>" placeholder="{score}/{best} - ({count} {votes})" class="regular-text" style="font-family: monospace;">
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('متنی که پس از رأی گیری نمایش داده می شود.', 'tag-star-ratings'); ?>
                    <br><br>
                    <?php echo esc_html__('متغیرهای زیر در دسترس هستند:', 'tag-star-ratings'); ?>
                    <br>
                    <?php echo sprintf(esc_html__('%s میانگین امتیازات', 'tag-star-ratings'), '<code>{score}</code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html__('%s تعداد آرای داده شده', 'tag-star-ratings'), '<code>{count}</code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html__('%s تعداد کل ستاره ها', 'tag-star-ratings'), '<code>{best} </code>'); ?>
                    <br>
                    <?php echo sprintf(esc_html__('%s رای', 'tag-star-ratings'), '<code>{votes}</code>'); ?>
                </p>
            </td>
        </tr>

        <!-- Stars -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo esc_attr($stars[0]); ?>">
                    <?php echo esc_html_x('ستاره ها', 'Label', 'tag-star-ratings'); ?>
                </label>
            </th>
            <td>
                <p>
                    <input type="number" name="<?php echo esc_attr($stars[0]); ?>" id="<?php echo esc_attr($stars[0]); ?>" value="<?php echo esc_attr($stars[1]); ?>" class="regular-text" style="max-width: 4rem; padding-right: 0;">
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('تعداد کل ستاره ها', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Gap -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo $gap[0]; ?>">
                    <?php echo esc_html_x('گپ', 'Label', 'tag-star-ratings'); ?>
                </label>
            </th>
            <td>
                <p>
                    <input type="number" name="<?php echo esc_attr($gap[0]); ?>" id="<?php echo esc_attr($gap[0]); ?>" value="<?php echo esc_attr($gap[1]); ?>" class="regular-text" style="max-width: 4rem; padding-right: 0;">
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('فاصله بین ستاره ها', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Size -->
        <tr>
            <th scope="row" valign="top">
                <label for="<?php echo $size[0]; ?>">
                    <?php echo esc_html_x('اندازه', 'Label', 'tag-star-ratings'); ?>
                </label>
            </th>
            <td>
                <p>
                    <input type="number" name="<?php echo esc_attr($size[0]); ?>" id="<?php echo esc_attr($size[0]); ?>" value="<?php echo esc_attr($size[1]); ?>" class="regular-text" style="max-width: 4rem; padding-right: 0;">
                </p>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('اندازه یک ستاره.', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>

        <!-- Position -->
        <tr>
            <th scope="row" valign="top">
                <?php echo esc_html_x('موقعیت پیشفرض', 'Label', 'tag-star-ratings'); ?>
            </th>
            <td>
                <?php foreach ($positions as $value => $label) { ?>
                    <p>
                        <label>
                            <input type="radio" name="<?php echo esc_attr($position[0]); ?>" value="<?php echo esc_attr($value); ?>"<?php echo ($value == $position[1]) ? ' checked="checked"' : ''; ?>>
                            <?php echo esc_html($label); ?>
                        </label>
                    </p>
                <?php } ?>
                <p class="description" style="max-width: 22rem; margin-top: .75rem;">
                    <?php echo esc_html__('موقعیت پیش فرض را برای رتبه بندی ستاره های تعبیه شده خودکار انتخاب کنید.', 'tag-star-ratings'); ?>
                </p>
            </td>
        </tr>
    </tbody>
</table>
