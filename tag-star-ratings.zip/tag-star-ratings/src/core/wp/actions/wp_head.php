<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\wp\actions;

use function Tagtech\StarRating\core\functions\action;
use function Tagtech\StarRating\core\functions\data;
use function Tagtech\StarRating\core\functions\option;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function wp_head(): void
{
    if (option('enable') && option('grs') && is_singular()) {
        $payload = data();

        if ($payload['count'] && $payload['score']) {
            ob_start();
            action('sd', $payload);
            echo ob_get_clean();
        }
    }
}
