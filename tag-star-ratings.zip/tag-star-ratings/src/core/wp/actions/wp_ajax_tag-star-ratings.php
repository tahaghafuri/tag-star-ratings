<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\wp\actions;

use function Tagtech\StarRating\core\functions\action;
use function Tagtech\StarRating\core\functions\filter;
use function Tagtech\StarRating\functions\cast;
use function Tagtech\StarRating\functions\sanitize;
use function Tagtech\StarRating\functions\to_shortcode;
use Exception;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function wp_ajax_TAG_star_ratings()
{
    try {
        if (! check_ajax_referer(__FUNCTION__, 'nonce', false)) {
            throw new Exception(__('این عمل ممنوع است..', 'tag-star-ratings'), 403);
        }

        $payload = sanitize($_POST['payload'] ?? []);

        $id = intval($payload['id'] ?? 0);
        $slug = $payload['slug'] ?? 'default';
        $best = intval($payload['best'] ?? 5);

        if (filter('validate', null, $payload['id'], $payload['slug'], $payload) === false) {
            throw new Exception(__('در حال حاضر رتبه ای قابل قبول نیست.', 'tag-star-ratings'));
        }

        if (! isset($_POST['rating'])) {
            throw new Exception(__('برای رای دادن نیاز به رتبه بندی است.', 'tag-star-ratings'));
        }

        $rating = intval($_POST['rating'] ?? 0);

        if ($rating < 1 || $rating > $best) {
            throw new Exception(sprintf(__('مقدار رتبه بندی باید بین %1$d و %2$d باشد.', 'tag-star-ratings'), 1, $best));
        }

        $outOf5 = cast($rating, 5, $best);

        action('save', $outOf5, $id, $slug, [
            'count' => (int) filter('count', null, $id, $slug),
            'ratings' => (float) filter('ratings', null, $id, $slug),
        ] + $payload);

        $payload['legend'] = $payload['_legend'];

        unset($payload['count'], $payload['score']);

        $html = trim(do_shortcode(to_shortcode(tagsr('slug'), $payload)));

        wp_die($html, 201);
    } catch (Exception $e) {
        header('Content-Type: application/json; charset=utf-8');

        wp_die(json_encode(['error' => $e->getMessage()]), $e->getCode() ?: 406);
    }
}
