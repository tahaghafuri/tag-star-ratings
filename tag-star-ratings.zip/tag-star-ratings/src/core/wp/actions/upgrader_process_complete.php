<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\wp\actions;

use function Tagtech\StarRating\core\wp\functions\deactivate;
use WP_Upgrader;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function upgrader_process_complete(WP_Upgrader $upgrader, array $options): void
{
    if ($options['action'] == 'update'
        && $options['type'] == 'plugin'
        && isset($options['plugin'])
        && in_array(tagsr('signature'), $options['plugins'])
    ) {
        deactivate();
    }
}
