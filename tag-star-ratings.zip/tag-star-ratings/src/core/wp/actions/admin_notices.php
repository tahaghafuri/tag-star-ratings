<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\wp\actions;

use function Tagtech\StarRating\core\functions\migrations;
use function Tagtech\StarRating\core\functions\view;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function admin_notices(): void
{
    // if (! migrations()->isEmpty()) {
    //     $icon = get_admin_url(null, 'images/wpspin_light.gif');
    //     $message = sprintf(__('%s has pending migrations. These migrations are running in the background and the ratings will remain disabled until the migrations have finished.', 'tag-star-ratings'), tagsr('name'));
    //     $type = 'warning';

    //     echo view('notice.php', compact('icon', 'message', 'type'));
    // }
}
