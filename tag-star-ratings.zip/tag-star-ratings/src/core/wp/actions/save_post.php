<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\wp\actions;

use function Tagtech\StarRating\core\functions\action;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function save_post($id): void
{
    if (wp_verify_nonce($_POST[tagsr('slug').'-metabox'] ?? '', __FUNCTION__)
        && ! (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        && current_user_can('edit_post', $id)
    ) {
        action('metabox/save', $id, $_POST);
    }
}
