<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

use function Tagtech\StarRating\functions\get_hof;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

/** @param int|string $id */
function get_meta_hof(?array $payload, $id): callable
{
    $delegate = function (string $key, $default = null) use ($id) {
        return post_meta($id, $key, $default);
    };

    return get_hof($payload, $delegate, '_'.tagsr('nick').'_', array_map('gettype', tagsr('core.post_meta')));
}
