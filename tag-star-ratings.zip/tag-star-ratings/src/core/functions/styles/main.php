<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions\styles;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function main(bool $isDebugMode = false): void
{
    wp_enqueue_style(
        tagsr('slug'),
        tagsr('core.url').'public/css/tag-star-ratings'
            .($isDebugMode ? '' : '.min').'.css',
        [],
        tagsr('version')
    );
}
