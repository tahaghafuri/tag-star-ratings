<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

use function Tagtech\StarRating\functions\cast;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function calculate(int $id, string $slug, int $best = 5): array
{
    $count = (int) filter('count', null, $id, $slug);
    $ratings = (float) filter('ratings', null, $id, $slug);
    $score = $count ? ($ratings / $count) : 0;
    $score = (float) min(max(0, cast($score, $best)), $best);
    $score = filter('score', $score);

    return [$count, $score];
}
