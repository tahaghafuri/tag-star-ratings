<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

use function Tagtech\StarRating\functions\prefix;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

/**
 * @param string|array $strOrPayload
 *
 * @return string|array
 */
function meta_prefix($strOrPayload)
{
    return prefix($strOrPayload, '_'.tagsr('nick').'_');
}
