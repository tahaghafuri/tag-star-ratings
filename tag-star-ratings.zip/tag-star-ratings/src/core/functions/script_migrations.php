<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function script_migrations(bool $isDebugMode = false): void
{
    wp_enqueue_script(
        tagsr('nick').'-migrations',
        tagsr('core.url').'public/js/tagsr-migrations'
            .($isDebugMode ? '' : '.min').'.js',
        ['jquery'],
        tagsr('version'),
        true
    );

    wp_localize_script(
        tagsr('nick').'-migrations',
        str_replace('-', '_', tagsr('nick')).'_migrations',
        [
            'action' => tagsr('nick').'-migrations',
            'endpoint' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(tagsr('core.wp.actions.wp_ajax_'.tagsr('nick').'-migrations')),
        ]
    );
}
