<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

use function Tagtech\StarRating\functions\explode_prefix as base_explode_prefix;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function explode_prefix(string $key): array
{
    return base_explode_prefix($key, tagsr('nick').'_');
}
