<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\functions;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function response(array $payload): string
{
    $payload += array_fill_keys([
        'align', 'count', 'id', 'readonly',
        'score', 'slug', 'valign',
    ], '') + [
        'best' => option('stars'),
        'gap' => option('gap'),
        'greet' => option('greet'),
        'legend' => option('legend'),
        'size' => option('size'),
    ];

    $payload['best'] = (int) $payload['best'];
    $payload['gap'] = (int) $payload['gap'];
    $payload['id'] = (int) $payload['id'];
    $payload['readonly'] = (bool) $payload['readonly'];
    $payload['size'] = (int) $payload['size'];

    $payload = filter('payload', $payload);

    $payload['greet'] = str_replace('{type}', get_post_type($payload['id']) ?: 'post', $payload['greet']);
    $payload['_legend'] = $payload['legend'];
    $payload['legend'] = str_replace('{best}', $payload['best'], $payload['legend']);
    $payload['legend'] = str_replace('{count}', $payload['count'], $payload['legend']);
    $payload['legend'] = str_replace('{score}', $payload['score'], $payload['legend']);
    $payload['legend'] = str_replace('{votes}', _n('vote', 'votes', $payload['count'], 'tag-star-ratings'), $payload['legend']);

    ob_start();

    action('markup', $payload);

    return ob_get_clean();
}
