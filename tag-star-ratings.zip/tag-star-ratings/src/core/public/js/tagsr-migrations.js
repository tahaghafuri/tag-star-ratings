/**
 * tag Star Ratings
 * @see https://tagtech.ir/p/tag-star-rating/
 */

"use strict";

jQuery(document).ready(function ($) {
  function ajax(successCallback, errorCallback) {
    $.ajax({
      type: "POST",
      url: tagsr_migrations.endpoint,
      data: {
        nonce: tagsr_migrations.nonce,
        action: tagsr_migrations.action,
      },
      error: errorCallback,
      success: successCallback,
    });
  }

  function migrate() {
    ajax(
      function (response, status, xhr) {
        if (response && response.data) {
          if (response.data.status == "pending") {
            migrate();
          } else if (response.data.status == "busy") {
            setTimeout(migrate, 5000);
          }
        }
      },
      function (xhr, status, err) {
        if (xhr.responseJSON && xhr.responseJSON.error) {
          console.error(xhr.responseJSON.error);
          setTimeout(migrate, 5000);
        }
      }
    );
  }

  migrate();
});
