<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\filters\admin;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function tabs(array $tabs): array
{
    return $tabs + [
        'general' => _x('عمومی', 'Label', 'tag-star-ratings'),
        'appearance' => _x('ظاهر', 'Label', 'tag-star-ratings'),
        'rich_snippets' => _x('ریچ اسنیپت ها', 'Label', 'tag-star-ratings'),
        // 'tab' => [
        //     'name' => _x('Name', 'Label', 'tag-star-ratings'),
        //     'is_disabled' => true,
        //     'is_addon' => false,
        // ],
    ];
}
