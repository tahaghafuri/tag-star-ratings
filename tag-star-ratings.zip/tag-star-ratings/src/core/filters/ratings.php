<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\filters;

use function Tagtech\StarRating\core\functions\post_meta;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function ratings(?float $ratings, int $id, string $slug): float
{
    if (! is_null($ratings)) {
        return $ratings;
    }

    return (float) post_meta($id, "ratings_{$slug}");
}
