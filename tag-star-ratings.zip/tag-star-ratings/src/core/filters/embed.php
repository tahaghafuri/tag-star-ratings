<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\filters;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

/** Whether to auto-embed the star ratings in a post. */
function embed(?bool $bool, string $content): bool
{
    if (! is_null($bool)) {
        return $bool;
    }

    foreach ([
        tagsr('slug'),
        // Legacy...
        'tagratings', // < v3
        'tagstarratings', // v3, v4
    ] as $tag) {
        if (has_shortcode($content, $tag)) {
            return false;
        }
    }

    return true;
}
