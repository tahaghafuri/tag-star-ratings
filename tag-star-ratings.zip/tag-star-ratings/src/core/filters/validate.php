<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\filters;

use function Tagtech\StarRating\core\functions\filter;
use function Tagtech\StarRating\core\functions\migrations;
use function Tagtech\StarRating\core\functions\option;
use Exception;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function validate(?bool $valid, int $id, string $slug, array $payload): bool
{
    if (! is_null($valid)) {
        return $valid;
    }

    if ($payload['readonly'] ?? false) {
        throw new Exception(__('رتبه بندی ها فقط خواندنی هستند.', 'tag-star-ratings'));
    }

    // if (! migrations()->isEmpty()) {
    //     throw new Exception(__('تحت تعمیر و نگهداری', 'tag-star-ratings'));
    // }

    if (! option('enable')) {
        throw new Exception(__('در حال حاضر مجاز نیست.', 'tag-star-ratings'));
    }

    $strategies = (array) option('strategies');

    if (is_archive()
        && ! in_array('archives', $strategies)
    ) {
        throw new Exception(__('شما نمی توانید در آرشیو رای بدهید.', 'tag-star-ratings'));
    }

    if (! (is_user_logged_in()
        || in_array('guests', $strategies)
    )) {
        throw new Exception(__('برای رای دادن نیاز به احرازهویت دارید.', 'tag-star-ratings'), 401);
    }

    $fingerprint = filter('fingerprint', null, $id, $slug);

    if (in_array('unique', $strategies)
        && ! filter('unique', null, $fingerprint, $id, $slug)
    ) {
        throw new Exception(__('شما قبلا رای خود را داده اید.', 'tag-star-ratings'), 403);
    }

    return true;
}
