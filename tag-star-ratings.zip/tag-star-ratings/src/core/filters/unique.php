<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Tagtech\StarRating\core\filters;

use function Tagtech\StarRating\core\functions\post_meta;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

function unique(?bool $bool, string $fingerprint, int $id, string $slug): bool
{
    if (! is_null($bool)) {
        return $bool;
    }

    return ! in_array($fingerprint, post_meta($id, "fingerprint_{$slug}[]"));
}
