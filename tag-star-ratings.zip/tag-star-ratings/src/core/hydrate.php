<?php

/*
 * This file is part of tagtech/tag-star-ratings.
 *
 * (c) TAGTECH <info@tagtech.ir>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

use function Tagtech\StarRating\functions\hook;

if (! defined('TAG_STAR_RATINGS')) {
    http_response_code(404);
    exit();
}

foreach (tagsr('core.wp.actions') as $tag => $fn) {
    hook('action', $tag, $fn);
}

foreach (tagsr('core.wp.filters') as $tag => $fn) {
    hook('filter', $tag, $fn);
}

foreach (tagsr('core.wp.shortcodes') as $tag => $fn) {
    add_shortcode($tag, $fn);
}
